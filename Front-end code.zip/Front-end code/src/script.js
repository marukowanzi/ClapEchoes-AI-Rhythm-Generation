let port;
let writer;
let reader;

let Tone = mm.Player.tone;
let midiDrums = [36];
let reverseMidiMapping = new Map([[36, 0]]);
const audioCache = {};


let temperature = 1.0;


let timestamps = [];
let startTime = null;
let isAppVisible = false;
const duration = 8000; // 1 seconds duration for the pattern
const duration_generate = 8000;
const duration_countDown = 4000;
const numberOfSteps = 16; // Number of steps in the sequencer
let isHumanInputEnabled = false;
let countDownTimer; // timerID
const audioCacheA = {};

let rnn = new mm.MusicRNN( "https://storage.googleapis.com/download.magenta.tensorflow.org/tfjs_checkpoints/music_rnn/drum_kit_rnn"
);
rnn.initialize();

function showAppContent() {
  
  setTimeout(() => {
      document.querySelector(".title").style.display = 'none';
      document.querySelector(".subtitle").style.display = 'none';
      document.querySelector(".bg_box").style.display = 'none';
      document.querySelector("#connect").style.display = 'none';
      document.querySelector(".app").style.display = 'block';
      isAppVisible = true; 
      startCountDown(); // Start the loop automatically
    }, 2000); // 2000 milliseconds = 2 seconds
  
  }

async function connectToArduino() {
    try {
      port = await navigator.serial.requestPort();
      await port.open({ baudRate: 9600 });
      writer = port.writable.getWriter();
      reader = port.readable.getReader();
      console.log('Connected to Arduino');
      
      
    } catch (error) {
      console.error('Connection failed', error);
      alert(`Connection failed: ${error.message}`);
      document.querySelector("#connect").style.display = 'block';
      document.querySelector(".progress").style.display = 'none';
    }
  }

function renderPattern(selector, numberOfSteps) {
      // 获取 .steps 容器元素
      const stepsContainer = document.querySelector(selector + ' .steps');

      // 清空现有的步骤
      stepsContainer.innerHTML = '';

      // 渲染指定数量的矩形
      for (let i = 0; i < numberOfSteps; i++) {
        const step = document.createElement('div');
        step.classList.add('step');
        stepsContainer.appendChild(step);
      }
    }
function lightUpStep(selector, index) {
  const stepElement = document.querySelector(`${selector} .steps .step:nth-child(${index + 1})`);
  if (stepElement) {
    stepElement.classList.add('on');
    stepElement.classList.add('flash-once');
    setTimeout(() => stepElement.classList.remove('flash-once'), 500); // 移除闪烁类
  }
}

function mapTimestampsToPattern(timestamps, duration, numberOfSteps) {
  console.log('Mapping timestamps to pattern:', timestamps);
  const pattern = Array.from({ length: numberOfSteps }, () => []);
 timestamps.forEach(timestamp => {
    const stepIndex = Math.floor((timestamp / duration) * numberOfSteps);
    if (stepIndex < numberOfSteps) {
      pattern[stepIndex] = [0]; // 使用 [0] 表示有鼓点
    }
  });
  console.log('Stamped pattern:', pattern);
  return pattern;
}

function toNoteSequence(pattern) {
    return mm.sequences.quantizeNoteSequence(
      {
        ticksPerQuarter: 220,
        totalTime: pattern.length / 2,
        timeSignatures: [
          {
            time: 0,
            numerator: 4,
            denominator: 4
          }
        ],
        tempos: [
          {
            time: 0,
            qpm: 120
          }
        ],
        notes: _.flatMap(pattern, (step, index) =>
          step.map((d) => ({
            pitch: midiDrums[d],
            startTime: index * 0.5,
            endTime: (index + 1) * 0.5
          }))
        )
      },
      1
      
    );
  }
function fromNoteSequence(seq, patternLength) {
    let res = _.times(patternLength, () => []);
    for (let { pitch, quantizedStartStep } of seq.notes) {
      res[quantizedStartStep].push(reverseMidiMapping.get(pitch));
    }
    return res;
  }
function flattenPattern(pattern) {
    return pattern.map(step => step.length > 0 ? 1 : 0);
  }
function generatePattern(seed, length) {
    
    let seedSeq = toNoteSequence(seed);
    console.log("seed:", seedSeq);
    return rnn
        .continueSequence(seedSeq, length, temperature)
        .then(r => {
            let newPattern = seed.concat(fromNoteSequence(r, length));
            // Clean up the pattern by filtering out undefined values
            newPattern = newPattern.map(step => step.filter(d => d !== undefined));
            console.log("New pattern generated:", newPattern);
            return newPattern;
        });
}
function resetForNewInput() {
  timestamps = [];
  startTime = null;
  isHumanInputEnabled = true;
  renderPattern('#sequence_human', numberOfSteps);
  renderPattern('#sequence_ai', numberOfSteps);
}

function processInput() {
  if (!isHumanInputEnabled) return;
  const currentTime = Date.now();

  if (startTime === null) {
    startTime = Date.now();
  }
  const timestamp = currentTime - startTime;

  timestamps.push(timestamp);
  const pattern = mapTimestampsToPattern(timestamps, duration, numberOfSteps);
  console.log('Timestamp recorded:', timestamp);
  
  renderPattern('#sequence_human', numberOfSteps);
  
  
  pattern.forEach((step, index) => {
    if (step[0] === 0) {
      lightUpStep('#sequence_human', index); 
    }
  });

  if (timestamps.length >= numberOfSteps || currentTime - startTime >= duration) {
    isHumanInputEnabled = false;
    console.log('Human input disabled');

    setTimeout(async () => {
      const newPattern = await generatePattern(pattern, numberOfSteps);
      if (newPattern) {
        const aiGeneratedPattern = newPattern.slice(pattern.length);
        console.log('AI generated pattern:', aiGeneratedPattern);
        renderPattern('#sequence_ai', numberOfSteps);

        
        aiGeneratedPattern.forEach((step, index) => {
          if (step.length > 0 && step[0] === 0) {
            console.log(`Lighting up AI step ${index + 1}`);
            setTimeout(() => lightUpStep('#sequence_ai', index), index * 100);
            // document.querySelector(`#sequence_ai .steps .step:nth-child(${index + 1})`).classList.add('on');
          }
        });

        
        let aiflatPattern = flattenPattern(aiGeneratedPattern);
        console.log(aiflatPattern);
        await writer.write(new TextEncoder().encode(aiflatPattern.join(',') + '\n'));
        
        // Reset for new input and start next loop
        setTimeout(() => {
          resetForNewInput();
          startLoop();
        }, duration_generate); // 延迟6秒
      }
    });
  }
}
function processArduinoData(data) {
  if (data === '1') {
    console.log('Received "1" from Arduino');
    processInput();
  } else {
    console.log('Received unknown data from Arduino:', data);
  }
}

function handleKeydown(event) {
 
  if (event.code === 'Escape') {
    console.log('Escape key pressed');
    exitGame();
    isHumanInputEnabled = false;
  }
}

function startLoop() {
  console.log('Starting new loop');
  if (isHumanInputEnabled) {
    document.addEventListener('keydown', handleKeydown);
    listenToArduino();
  }
}
function playCountdownSound(step) {
  const stepUrls = {
    'ready': 'https://raw.githubusercontent.com/marukowanzi/soundupload/main/1-0.WAV',
    'go': 'https://raw.githubusercontent.com/marukowanzi/soundupload/main/2-0.WAV'
  };

  const audioUrl = stepUrls[step];

  if (!audioUrl) {
    console.error(`No URL defined for step: ${step}`);
    return;
  }

  // 检查是否已经缓存了这个音频
  if (!audioCacheA[step]) {
    audioCacheA[step] = new Audio(audioUrl);
  }

  
  const audio = audioCacheA[step];

  // 重置音频到开始并播放
  audio.currentTime = 0;
  audio.play().catch(error => {
    console.error(`Error playing sound ${step}:`, error);
  });

  console.log(`播放倒计时声音: ${step}`);
}

function startCountDown() {
  let count = 0;
  const steps = ['ready', 'go'];
  countDownTimer = setInterval(() => {
    if (count < steps.length) {
      playCountdownSound(steps[count]);
      console.log(steps[count]);
      count++;
    } else {
      clearInterval(countDownTimer);
      isHumanInputEnabled = true;
      startLoop();
    }
  }, 2000); // 每秒播放一个倒计时声音
}

function showHomePage() {
  document.querySelector(".title").style.display = 'block';
  document.querySelector(".subtitle").style.display = 'block';
  document.querySelector("#connect").style.display = 'block';
}
async function listenToArduino() {
  while (port && port.readable) {
    try {
      const { value, done } = await reader.read();
      if (done) {
        // 读取完成，跳出循环
        break;
      }
      if (value) {
        const data = new TextDecoder().decode(value);
        console.log('Data from Arduino:', data);
        processArduinoData(data.trim()); // 处理从Arduino接收到的数据
      }
    } catch (error) {
      console.error('Error reading from Arduino', error);
      break;
    }
  }
}

async function closeArudino() {
  if (port) {
    try {
      if (writer) {
        await writer.releaseLock();
      }
      await port.close();
      console.log('Port closed successfully');
    } catch (error) {
      console.error('Error closing the port', error);
    } finally {
      port = null;
      writer = null;
      reader = null;
    }
  }
}
  
async function exitGame() {
  // Clean up resources, stop animations, and remove event listeners
  document.querySelector(".app").style.display = 'none';
  await closeArudino();
  showHomePage();
  isHumanInputEnabled = false;
  
  if (countDownTimer) {
    clearInterval(countDownTimer);
    countDownTimer = null; // 将计时器ID重置为null
  }
  
  
}
  
document.getElementById('connect').addEventListener('click', async () => {
  await connectToArduino();
  document.querySelector("#connect").style.display = 'none';
  document.querySelector(".bg_box").style.display = 'block';
  showAppContent(); 
  
  
});

document.addEventListener('DOMContentLoaded', (event) => {
  console.log('DOM fully loaded and parsed');
  renderPattern('#sequence_human', numberOfSteps); // Initial render with 24 steps
  renderPattern('#sequence_ai', numberOfSteps); // Initial render with 24 steps
});
