# ClappEchoesFinal

A Pen created on CodePen.io. Original URL: [https://codepen.io/marukowanzi/pen/pomxrpw](https://codepen.io/marukowanzi/pen/pomxrpw).

Uses the "Drums RNN" pretrained model from Google Magenta https://github.com/tensorflow/magenta/tree/master/magenta/models/drums_rnn

Running on Magenta.js, TensorFlow.js and Tone.js

The arduino is connected to custom made clapping machine full details will be shared in the future. The machine uses one sg90 servo connected to pwm pin3.

